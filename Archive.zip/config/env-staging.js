//DEVELOPMENT ENVIROMENT
module.exports = {
	DB_AUTH: "mongodb+srv://qudo-main:1HostTheQudo@$@cluster0-g4skd.mongodb.net/test?retryWrites=true&w=majority",
	JWT_SECRET: "",
	HEADERS: {
		'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept',
    'Content-Type': 'application/json',
    'Access-Control-Allow-Methods': '*',
    'Access-Control-Max-Age': '2592000',
    'Access-Control-Allow-Credentials': 'true',
	}
}